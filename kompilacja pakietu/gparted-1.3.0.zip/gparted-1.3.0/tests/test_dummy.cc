/* Copyright (C) 2017 Mike Fleetwood
 *
 *  Copying and distribution of this file, with or without modification,
 *  are permitted in any medium without royalty provided the copyright
 *  notice and this notice are preserved.  This file is offered as-is,
 *  without any warranty.
 */

#include "gtest/gtest.h"

TEST( DummyTest, Success )
{
	EXPECT_TRUE( true );
}
